# INSTRUCTIONS
Découverte du SVG et des transitions CSS

## HTML
- Utilisation d'images en SVG

## CSS
- Utilisation des transitions et transformations en CSS
- Largeur limité à 1100px maximum
- Police utilisé : "Bree Serif"
- Taille de police (a convertir en rem) :
    texte: 18px
    nav : 20px
    logo et h1 : 40px
    h2 : 35px
    h3 des compétences : 30px
    icone : 25px
    input et textarea : 16px

## TRANSITIONS
- logo :
    - zoom de 1.3 sur le losange
    - texte qui passe en rose

- nav :
    - texte et icones passent en rose
    - texte et icones descendent de 10px

- en savoir plus : background rose

## BONUS
- Faire un effet "bounce" en CSS sur les 3 petites icones de "On discute / on tente / on code".
